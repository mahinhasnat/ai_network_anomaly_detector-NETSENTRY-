"""
data_generator.py
------------------
Generates realistic, flow-based network traffic data for training and
testing the anomaly detector. Each row is one "network flow" (a connection
between a source and destination, similar to what NetFlow/Zeek would log).

Includes normal traffic + 4 common attack patterns:
  - Port Scan
  - DoS / DDoS flood
  - Brute Force login attempts
  - Data Exfiltration

This lets you train and demo the system without needing a live network
capture or a downloaded dataset (e.g. CICIDS / NSL-KDD).
"""

import numpy as np
import pandas as pd
import random
import time

PROTOCOLS = ["TCP", "UDP", "ICMP"]
COMMON_PORTS = [80, 443, 53, 22, 25, 110, 143, 21, 3306, 8080]

rng = np.random.default_rng(42)


def _base_flow(label="normal", attack_type="none"):
    return {
        "duration": 0.0,
        "protocol": "TCP",
        "src_port": random.randint(1024, 65535),
        "dst_port": random.choice(COMMON_PORTS),
        "packet_count": 0,
        "src_bytes": 0,
        "dst_bytes": 0,
        "unique_dst_ports_5s": 1,   # how many distinct dst ports this src hit in last 5s
        "conn_count_5s": 1,         # how many connections this src made in last 5s
        "failed_logins": 0,
        "syn_ratio": 0.2,           # fraction of packets that are SYN (connection attempts)
        "avg_packet_size": 0.0,
        "label": label,
        "attack_type": attack_type,
    }


def generate_normal_flow():
    f = _base_flow("normal", "none")
    f["duration"] = round(rng.exponential(8) + 0.1, 3)
    f["protocol"] = random.choices(PROTOCOLS, weights=[0.75, 0.2, 0.05])[0]
    f["dst_port"] = random.choice(COMMON_PORTS)
    f["packet_count"] = int(rng.normal(40, 15))
    f["packet_count"] = max(2, f["packet_count"])
    f["src_bytes"] = int(abs(rng.normal(3000, 1500)))
    f["dst_bytes"] = int(abs(rng.normal(9000, 4000)))
    f["unique_dst_ports_5s"] = random.choice([1, 1, 1, 2])
    f["conn_count_5s"] = random.choice([1, 1, 2, 3])
    f["failed_logins"] = 0
    f["syn_ratio"] = round(rng.uniform(0.05, 0.25), 3)
    total_bytes = f["src_bytes"] + f["dst_bytes"]
    f["avg_packet_size"] = round(total_bytes / max(1, f["packet_count"]), 2)
    return f


def generate_port_scan_flow():
    f = _base_flow("attack", "port_scan")
    f["duration"] = round(rng.uniform(0.001, 0.05), 4)
    f["protocol"] = "TCP"
    f["dst_port"] = random.randint(1, 65535)
    f["packet_count"] = random.randint(1, 3)
    f["src_bytes"] = random.randint(40, 100)
    f["dst_bytes"] = random.randint(0, 60)
    f["unique_dst_ports_5s"] = random.randint(30, 500)   # hallmark of scanning
    f["conn_count_5s"] = random.randint(30, 500)
    f["failed_logins"] = 0
    f["syn_ratio"] = round(rng.uniform(0.9, 1.0), 3)
    total_bytes = f["src_bytes"] + f["dst_bytes"]
    f["avg_packet_size"] = round(total_bytes / max(1, f["packet_count"]), 2)
    return f


def generate_dos_flow():
    f = _base_flow("attack", "dos")
    f["duration"] = round(rng.uniform(0.001, 0.2), 4)
    f["protocol"] = random.choice(["TCP", "UDP", "ICMP"])
    f["dst_port"] = random.choice([80, 443])
    f["packet_count"] = int(rng.normal(3000, 800))
    f["packet_count"] = max(500, f["packet_count"])
    f["src_bytes"] = int(abs(rng.normal(200, 50))) * f["packet_count"] // 50
    f["dst_bytes"] = random.randint(0, 100)
    f["unique_dst_ports_5s"] = 1
    f["conn_count_5s"] = random.randint(500, 5000)   # flood of connections
    f["failed_logins"] = 0
    f["syn_ratio"] = round(rng.uniform(0.85, 1.0), 3)
    total_bytes = f["src_bytes"] + f["dst_bytes"]
    f["avg_packet_size"] = round(total_bytes / max(1, f["packet_count"]), 2)
    return f


def generate_bruteforce_flow():
    f = _base_flow("attack", "brute_force")
    f["duration"] = round(rng.uniform(0.1, 2.0), 3)
    f["protocol"] = "TCP"
    f["dst_port"] = random.choice([22, 21, 3389, 3306])
    f["packet_count"] = random.randint(5, 20)
    f["src_bytes"] = random.randint(200, 800)
    f["dst_bytes"] = random.randint(100, 400)
    f["unique_dst_ports_5s"] = 1
    f["conn_count_5s"] = random.randint(20, 200)   # many repeated attempts to same port
    f["failed_logins"] = random.randint(5, 50)     # hallmark of brute force
    f["syn_ratio"] = round(rng.uniform(0.3, 0.6), 3)
    total_bytes = f["src_bytes"] + f["dst_bytes"]
    f["avg_packet_size"] = round(total_bytes / max(1, f["packet_count"]), 2)
    return f


def generate_exfiltration_flow():
    f = _base_flow("attack", "data_exfiltration")
    f["duration"] = round(rng.uniform(30, 300), 2)
    f["protocol"] = random.choice(["TCP", "UDP"])
    f["dst_port"] = random.choice([443, 8080, 53])
    f["packet_count"] = int(rng.normal(800, 200))
    f["packet_count"] = max(100, f["packet_count"])
    f["src_bytes"] = int(abs(rng.normal(50_000_000, 15_000_000)))  # huge outbound bytes
    f["dst_bytes"] = random.randint(500, 3000)
    f["unique_dst_ports_5s"] = 1
    f["conn_count_5s"] = 1
    f["failed_logins"] = 0
    f["syn_ratio"] = round(rng.uniform(0.02, 0.1), 3)
    total_bytes = f["src_bytes"] + f["dst_bytes"]
    f["avg_packet_size"] = round(total_bytes / max(1, f["packet_count"]), 2)
    return f


ATTACK_GENERATORS = {
    "port_scan": generate_port_scan_flow,
    "dos": generate_dos_flow,
    "brute_force": generate_bruteforce_flow,
    "data_exfiltration": generate_exfiltration_flow,
}


def generate_dataset(n_normal=5000, attack_ratio=0.08, seed=42):
    """
    Generates a labeled dataset. Labels are kept ONLY for evaluation --
    the actual anomaly detector trains unsupervised (it never sees labels).
    """
    random.seed(seed)
    np.random.seed(seed)

    rows = [generate_normal_flow() for _ in range(n_normal)]

    n_attacks = int(n_normal * attack_ratio)
    attack_types = list(ATTACK_GENERATORS.keys())
    for _ in range(n_attacks):
        atype = random.choice(attack_types)
        rows.append(ATTACK_GENERATORS[atype]())

    df = pd.DataFrame(rows)
    df = df.sample(frac=1, random_state=seed).reset_index(drop=True)  # shuffle
    df.insert(0, "flow_id", range(1, len(df) + 1))
    df.insert(1, "timestamp", [time.time() - random.uniform(0, 3600) for _ in range(len(df))])
    return df


def generate_single_live_flow():
    """Used by the live simulator to emit one flow at a time (normal or attack)."""
    if random.random() < 0.06:
        atype = random.choice(list(ATTACK_GENERATORS.keys()))
        flow = ATTACK_GENERATORS[atype]()
    else:
        flow = generate_normal_flow()
    flow["timestamp"] = time.time()
    return flow


if __name__ == "__main__":
    df = generate_dataset(n_normal=8000, attack_ratio=0.08)
    out_path = "data/network_traffic.csv"
    df.to_csv(out_path, index=False)
    print(f"Generated {len(df)} flows -> {out_path}")
    print(df["attack_type"].value_counts())
