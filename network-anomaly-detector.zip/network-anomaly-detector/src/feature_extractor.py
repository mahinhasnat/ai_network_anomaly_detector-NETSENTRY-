"""
feature_extractor.py
---------------------
Converts raw flow records (dicts or DataFrame rows) into a numeric feature
matrix the ML models can use. Also groups raw packets into flows if you're
using the optional live-capture mode.

Design note: features are chosen to be things a real NetFlow/Zeek log or a
packet-capture summarizer would give you, so this maps directly onto real
traffic if you swap the synthetic generator for a live capture source.
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
import joblib

NUMERIC_FEATURES = [
    "duration",
    "packet_count",
    "src_bytes",
    "dst_bytes",
    "unique_dst_ports_5s",
    "conn_count_5s",
    "failed_logins",
    "syn_ratio",
    "avg_packet_size",
]

PROTOCOL_MAP = {"TCP": 0, "UDP": 1, "ICMP": 2}


def encode_protocol(proto):
    return PROTOCOL_MAP.get(proto, 3)


def flows_to_dataframe(flows):
    """Accepts a list of flow dicts and returns a clean DataFrame."""
    df = pd.DataFrame(flows)
    return df


def extract_features(df):
    """
    Takes a DataFrame with raw flow columns and returns:
      X: numeric feature matrix (numpy array), log-scaled where useful
      feature_names: list of column names in X, in order
    """
    df = df.copy()
    df["protocol_enc"] = df["protocol"].apply(encode_protocol)

    # Log-scale heavy-tailed byte/count features so huge values (e.g. a
    # 50MB exfiltration flow) don't just get treated as generic "big number".
    for col in ["packet_count", "src_bytes", "dst_bytes", "avg_packet_size",
                "unique_dst_ports_5s", "conn_count_5s"]:
        df[col + "_log"] = np.log1p(df[col].clip(lower=0))

    feature_cols = [
        "duration",
        "protocol_enc",
        "packet_count_log",
        "src_bytes_log",
        "dst_bytes_log",
        "unique_dst_ports_5s_log",
        "conn_count_5s_log",
        "failed_logins",
        "syn_ratio",
        "avg_packet_size_log",
    ]

    X = df[feature_cols].fillna(0).to_numpy(dtype=float)
    return X, feature_cols


def fit_scaler(X):
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    return scaler, X_scaled


def save_scaler(scaler, path="models/scaler.pkl"):
    joblib.dump(scaler, path)


def load_scaler(path="models/scaler.pkl"):
    return joblib.load(path)


def transform_new(df, scaler):
    """Use this at detection time: same feature extraction, existing scaler."""
    X, feature_cols = extract_features(df)
    X_scaled = scaler.transform(X)
    return X_scaled, feature_cols
