"""
live_simulator.py
------------------
Simulates a live stream of network traffic and runs it through the trained
detector in real time. This lets you demo/test the full pipeline without
needing root privileges or a live network interface.

To monitor REAL traffic instead, replace `generate_single_live_flow()` with
flows built by `live_capture.py` (uses scapy to sniff real packets) -- the
detector code does not change at all, only the source of flow dicts.

Usage:
    python3 src/live_simulator.py               # runs until Ctrl+C
    python3 src/live_simulator.py --count 200    # run 200 flows then stop
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

import time
import argparse
import pandas as pd

from data_generator import generate_single_live_flow
from detector import AnomalyDetector


def run(count=None, delay=0.05):
    detector = AnomalyDetector()
    print("[*] Live monitor started. Watching simulated traffic... (Ctrl+C to stop)\n")
    n = 0
    try:
        while count is None or n < count:
            flow = generate_single_live_flow()
            df = pd.DataFrame([flow])
            detector.process_and_log(df, only_flagged=True, verbose=True)
            n += 1
            time.sleep(delay)
    except KeyboardInterrupt:
        print(f"\n[*] Stopped after {n} flows.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--count", type=int, default=None, help="number of flows to simulate (default: infinite)")
    parser.add_argument("--delay", type=float, default=0.05, help="seconds between flows")
    args = parser.parse_args()
    run(count=args.count, delay=args.delay)
