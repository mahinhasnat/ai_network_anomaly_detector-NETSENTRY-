"""
live_capture.py
-----------------
OPTIONAL module for monitoring REAL network traffic instead of simulated
traffic. Requires:
    pip install scapy
    sudo/admin privileges (raw packet capture needs elevated permissions)

This sniffs packets, groups them into flows (5-tuple: src ip/port, dst
ip/port, protocol) over a sliding time window, converts each flow into the
same feature schema used everywhere else in this project, and feeds it to
AnomalyDetector -- so the ML models and dashboard work identically whether
traffic is simulated or real.

Run:
    sudo python3 src/live_capture.py --iface eth0
    sudo python3 src/live_capture.py --iface "Wi-Fi"     # Windows/macOS
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

import time
import argparse
from collections import defaultdict

import pandas as pd
from detector import AnomalyDetector

try:
    from scapy.all import sniff, IP, TCP, UDP, ICMP
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False


WINDOW_SECONDS = 5
_flow_buffer = defaultdict(lambda: {
    "packet_count": 0, "src_bytes": 0, "dst_bytes": 0,
    "start_time": None, "syn_count": 0, "dst_ports": set(),
})
_conn_counts = defaultdict(int)


def _proto_name(pkt):
    if pkt.haslayer(TCP):
        return "TCP"
    if pkt.haslayer(UDP):
        return "UDP"
    if pkt.haslayer(ICMP):
        return "ICMP"
    return "OTHER"


def _packet_to_flow_key(pkt):
    ip = pkt[IP]
    sport = pkt.sport if hasattr(pkt, "sport") else 0
    dport = pkt.dport if hasattr(pkt, "dport") else 0
    return (ip.src, ip.dst, sport, dport, _proto_name(pkt))


def _handle_packet(pkt, detector):
    if not pkt.haslayer(IP):
        return
    key = _packet_to_flow_key(pkt)
    now = time.time()
    buf = _flow_buffer[key]
    if buf["start_time"] is None:
        buf["start_time"] = now
    buf["packet_count"] += 1
    size = len(pkt)
    buf["src_bytes"] += size
    if pkt.haslayer(TCP) and pkt[TCP].flags & 0x02:  # SYN flag
        buf["syn_count"] += 1
    buf["dst_ports"].add(key[3])
    _conn_counts[key[0]] += 1  # connections per source IP

    # Flush flow if window elapsed
    if now - buf["start_time"] >= WINDOW_SECONDS:
        flow_record = {
            "timestamp": now,
            "duration": round(now - buf["start_time"], 3),
            "protocol": key[4],
            "src_port": key[2],
            "dst_port": key[3],
            "packet_count": buf["packet_count"],
            "src_bytes": buf["src_bytes"],
            "dst_bytes": 0,
            "unique_dst_ports_5s": len(buf["dst_ports"]),
            "conn_count_5s": _conn_counts[key[0]],
            "failed_logins": 0,  # would need app-layer parsing (e.g. SSH/FTP logs) to detect
            "syn_ratio": round(buf["syn_count"] / max(1, buf["packet_count"]), 3),
            "avg_packet_size": round(buf["src_bytes"] / max(1, buf["packet_count"]), 2),
        }
        df = pd.DataFrame([flow_record])
        detector.process_and_log(df, only_flagged=True, verbose=True)
        del _flow_buffer[key]


def main():
    if not SCAPY_AVAILABLE:
        print("[!] scapy is not installed. Run: pip install scapy")
        print("[!] Live packet capture also requires admin/root privileges.")
        sys.exit(1)

    parser = argparse.ArgumentParser()
    parser.add_argument("--iface", default=None, help="network interface to sniff, e.g. eth0, wlan0, 'Wi-Fi'")
    args = parser.parse_args()

    detector = AnomalyDetector()
    print(f"[*] Sniffing on interface: {args.iface or 'default'} (Ctrl+C to stop)")
    sniff(iface=args.iface, prn=lambda p: _handle_packet(p, detector), store=False)


if __name__ == "__main__":
    main()
