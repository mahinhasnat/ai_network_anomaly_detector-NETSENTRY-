"""
train_model.py
---------------
Trains an UNSUPERVISED anomaly detection ensemble on network flow data:

  1. Isolation Forest  - isolates outliers by random partitioning; great at
     catching flows that are structurally weird (e.g. a scan's tiny packets
     hitting hundreds of ports).
  2. Autoencoder (MLP) - learns to reconstruct "normal" traffic; flows it
     reconstructs badly (high error) are flagged as anomalous. Good at
     catching subtle multi-feature drift that Isolation Forest can miss.

Both models never see the attack/normal labels during training -- that's
the point of anomaly detection: it should catch attack types it has never
seen before, not just memorize known ones. Labels are only used afterwards
to *evaluate* how well it did.

Usage:
    python3 src/train_model.py
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import IsolationForest
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import classification_report, roc_auc_score

from feature_extractor import extract_features, fit_scaler, save_scaler

MODEL_DIR = "models"
DATA_PATH = "data/network_traffic.csv"


def train():
    os.makedirs(MODEL_DIR, exist_ok=True)

    print(f"[*] Loading dataset from {DATA_PATH} ...")
    df = pd.read_csv(DATA_PATH)
    print(f"[*] Loaded {len(df)} flows ({(df.label == 'attack').sum()} attacks, "
          f"{(df.label == 'normal').sum()} normal)")

    X, feature_cols = extract_features(df)
    scaler, X_scaled = fit_scaler(X)
    save_scaler(scaler, f"{MODEL_DIR}/scaler.pkl")

    # ---- Model 1: Isolation Forest ----
    print("[*] Training Isolation Forest ...")
    iso_forest = IsolationForest(
        n_estimators=200,
        contamination=0.08,   # our expected % of anomalies, tune per environment
        random_state=42,
        n_jobs=-1,
    )
    iso_forest.fit(X_scaled)
    joblib.dump(iso_forest, f"{MODEL_DIR}/isolation_forest.pkl")

    # ---- Model 2: Autoencoder (trained ONLY on data that looks normal) ----
    # We bootstrap "probably normal" data using Isolation Forest's own
    # judgment, since we're not supposed to rely on ground-truth labels.
    iso_scores = iso_forest.decision_function(X_scaled)
    normal_mask = iso_scores > np.percentile(iso_scores, 10)  # keep the "normal-looking" 90%
    X_normal = X_scaled[normal_mask]

    print(f"[*] Training Autoencoder on {len(X_normal)} normal-looking flows ...")
    autoencoder = MLPRegressor(
        hidden_layer_sizes=(6, 3, 6),   # bottleneck architecture = compressive autoencoder
        activation="tanh",
        max_iter=500,
        random_state=42,
        early_stopping=True,
    )
    autoencoder.fit(X_normal, X_normal)   # learns to reconstruct its own input
    joblib.dump(autoencoder, f"{MODEL_DIR}/autoencoder.pkl")

    # ---- Compute reconstruction error threshold ----
    recon = autoencoder.predict(X_scaled)
    recon_error = np.mean((X_scaled - recon) ** 2, axis=1)
    error_threshold = float(np.percentile(recon_error, 92))
    joblib.dump(error_threshold, f"{MODEL_DIR}/recon_threshold.pkl")

    joblib.dump(feature_cols, f"{MODEL_DIR}/feature_cols.pkl")

    print(f"[*] Reconstruction error threshold set at {error_threshold:.4f}")

    # ---- Evaluation against known labels (sanity check only) ----
    iso_pred = (iso_forest.predict(X_scaled) == -1).astype(int)  # 1 = anomaly
    ae_pred = (recon_error > error_threshold).astype(int)
    ensemble_pred = ((iso_pred + ae_pred) >= 1).astype(int)   # flag if EITHER model fires

    y_true = (df["label"] == "attack").astype(int).to_numpy()

    print("\n=== Isolation Forest alone ===")
    print(classification_report(y_true, iso_pred, target_names=["normal", "attack"], zero_division=0))

    print("=== Autoencoder alone ===")
    print(classification_report(y_true, ae_pred, target_names=["normal", "attack"], zero_division=0))

    print("=== Ensemble (Isolation Forest OR Autoencoder) ===")
    print(classification_report(y_true, ensemble_pred, target_names=["normal", "attack"], zero_division=0))

    try:
        auc = roc_auc_score(y_true, -iso_scores)  # lower iso score = more anomalous
        print(f"Isolation Forest ROC-AUC: {auc:.4f}")
    except Exception:
        pass

    print(f"\n[✓] Models saved to {MODEL_DIR}/")


if __name__ == "__main__":
    train()
