"""
detector.py
------------
Loads the trained models and scores incoming network flows in real time.
Each flow gets:
  - an Isolation Forest verdict + anomaly score
  - an Autoencoder reconstruction error + verdict
  - a combined severity rating (low/medium/high/critical)
  - a best-guess reason (which features looked abnormal), for human review

Flagged flows are written to a SQLite database (logs/alerts.db) which the
Flask dashboard reads from, and printed to the console.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

import time
import sqlite3
import numpy as np
import pandas as pd
import joblib

from feature_extractor import extract_features

MODEL_DIR = "models"
DB_PATH = "logs/alerts.db"


class AnomalyDetector:
    def __init__(self, model_dir=MODEL_DIR):
        self.scaler = joblib.load(f"{model_dir}/scaler.pkl")
        self.iso_forest = joblib.load(f"{model_dir}/isolation_forest.pkl")
        self.autoencoder = joblib.load(f"{model_dir}/autoencoder.pkl")
        self.error_threshold = joblib.load(f"{model_dir}/recon_threshold.pkl")
        self.feature_cols = joblib.load(f"{model_dir}/feature_cols.pkl")
        self._init_db()

    def _init_db(self):
        os.makedirs("logs", exist_ok=True)
        conn = sqlite3.connect(DB_PATH)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts REAL,
                src_port INTEGER,
                dst_port INTEGER,
                protocol TEXT,
                duration REAL,
                packet_count INTEGER,
                src_bytes INTEGER,
                dst_bytes INTEGER,
                iso_score REAL,
                recon_error REAL,
                severity TEXT,
                reason TEXT,
                true_attack_type TEXT
            )
        """)
        conn.commit()
        conn.close()

    def _severity(self, iso_flag, ae_flag, iso_score, recon_error):
        if iso_flag and ae_flag:
            return "critical"
        if iso_flag or ae_flag:
            # scale medium/high by how far past threshold
            margin = recon_error / max(self.error_threshold, 1e-6)
            return "high" if margin > 1.5 else "medium"
        return "low"

    def _explain(self, row):
        """Very lightweight rule-based explanation to help a human analyst."""
        reasons = []
        if row.get("unique_dst_ports_5s", 0) > 20:
            reasons.append("many distinct destination ports (possible port scan)")
        if row.get("conn_count_5s", 0) > 300:
            reasons.append("very high connection rate (possible DoS/flood)")
        if row.get("failed_logins", 0) > 4:
            reasons.append("repeated failed logins (possible brute force)")
        if row.get("src_bytes", 0) > 5_000_000:
            reasons.append("unusually large outbound transfer (possible data exfiltration)")
        if row.get("syn_ratio", 0) > 0.85 and row.get("packet_count", 0) < 5:
            reasons.append("abnormal SYN ratio with tiny packet count")
        return "; ".join(reasons) if reasons else "statistical deviation from learned normal baseline"

    def score_batch(self, df):
        """
        Scores a DataFrame of raw flows. Returns the DataFrame with extra
        columns: iso_score, iso_flag, recon_error, ae_flag, severity, reason.
        """
        X, _ = extract_features(df)
        X_scaled = self.scaler.transform(X)

        iso_scores = self.iso_forest.decision_function(X_scaled)
        iso_flags = (self.iso_forest.predict(X_scaled) == -1)

        recon = self.autoencoder.predict(X_scaled)
        recon_errors = np.mean((X_scaled - recon) ** 2, axis=1)
        ae_flags = recon_errors > self.error_threshold

        out = df.copy()
        out["iso_score"] = iso_scores
        out["iso_flag"] = iso_flags
        out["recon_error"] = recon_errors
        out["ae_flag"] = ae_flags
        out["severity"] = [
            self._severity(i, a, s, r)
            for i, a, s, r in zip(iso_flags, ae_flags, iso_scores, recon_errors)
        ]
        out["reason"] = [self._explain(row) for _, row in out.iterrows()]
        return out

    def log_alert(self, row):
        conn = sqlite3.connect(DB_PATH)
        conn.execute(
            """INSERT INTO alerts
               (ts, src_port, dst_port, protocol, duration, packet_count,
                src_bytes, dst_bytes, iso_score, recon_error, severity, reason,
                true_attack_type)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                row.get("timestamp", time.time()),
                int(row.get("src_port", 0)),
                int(row.get("dst_port", 0)),
                str(row.get("protocol", "")),
                float(row.get("duration", 0)),
                int(row.get("packet_count", 0)),
                int(row.get("src_bytes", 0)),
                int(row.get("dst_bytes", 0)),
                float(row.get("iso_score", 0)),
                float(row.get("recon_error", 0)),
                str(row.get("severity", "")),
                str(row.get("reason", "")),
                str(row.get("attack_type", "unknown")),
            ),
        )
        conn.commit()
        conn.close()

    def process_and_log(self, df, only_flagged=True, verbose=True):
        scored = self.score_batch(df)
        flagged = scored[(scored["severity"] != "low")] if only_flagged else scored
        for _, row in flagged.iterrows():
            self.log_alert(row)
            if verbose:
                print(f"[{row['severity'].upper():8s}] port {row['dst_port']:>5} "
                      f"{row['protocol']:<4} | {row['reason']}")
        return scored


def score_csv(path):
    """Convenience: score a whole CSV file at once (batch mode)."""
    detector = AnomalyDetector()
    df = pd.read_csv(path)
    scored = detector.process_and_log(df, only_flagged=True)
    n_alerts = (scored["severity"] != "low").sum()
    print(f"\n[✓] Processed {len(df)} flows -> {n_alerts} alerts logged to {DB_PATH}")
    return scored


if __name__ == "__main__":
    score_csv("data/network_traffic.csv")
