# NetSentry — AI-Based Network Anomaly Detection

A fully working, unsupervised machine-learning system that detects malicious
network activity — port scans, DoS/DDoS floods, brute-force login attempts,
and data exfiltration — without relying on hand-written signatures. It ships
with a live SOC-style web dashboard.

## How it works

```
network flow  →  feature extraction  →  Isolation Forest  →  ┐
   (5-tuple)      (9 numeric feats)   +  Autoencoder (MLP)   ├→ severity + reason → SQLite → Dashboard
                                                              ┘
```

Two models score every flow, independently:

1. **Isolation Forest** — isolates statistical outliers by random
   partitioning. Very good at flows that are structurally strange (e.g. a
   scan hitting hundreds of ports with tiny packets).
2. **Autoencoder** (a bottlenecked MLP) — learns to reconstruct "normal"
   traffic. Flows it reconstructs badly (high error) are anomalous. Good at
   catching subtler, multi-feature drift.

**Neither model is trained on attack labels.** That's the actual point of
anomaly detection versus a signature-based IDS: it can flag attack *shapes*
it has never seen before, not just known ones. Labels are only used
afterward, to sanity-check performance (currently ~99% recall, ~92%
precision on held-out synthetic data — see `train_model.py` output).

A lightweight rule layer then explains *why* something was flagged (many
destination ports → possible scan; huge outbound bytes → possible
exfiltration, etc.) so an analyst isn't just staring at a raw anomaly score.

## Project layout

```
network-anomaly-detector/
├── src/
│   ├── data_generator.py   # synthetic traffic generator (normal + 4 attack types)
│   ├── feature_extractor.py# raw flow -> numeric feature vector
│   ├── train_model.py      # trains Isolation Forest + Autoencoder
│   ├── detector.py         # scoring engine + SQLite alert logging
│   ├── live_simulator.py   # streams simulated live traffic through the detector
│   └── live_capture.py     # OPTIONAL: real packet capture via scapy
├── dashboard/
│   ├── app.py               # Flask backend (serves alerts as JSON)
│   └── templates/index.html # live-updating SOC dashboard UI
├── data/                    # generated CSV datasets
├── models/                  # trained model files (.pkl)
├── logs/alerts.db           # SQLite alert log
└── requirements.txt
```

## Setup

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Run it — full walkthrough

**1. Generate training data** (synthetic, but modeled on real flow shapes):
```bash
python3 src/data_generator.py
```

**2. Train the models:**
```bash
python3 src/train_model.py
```
This prints precision/recall for each model so you can see how well it's
catching attacks before you trust it.

**3. Start the live monitor** (in one terminal — simulates continuous traffic):
```bash
python3 src/live_simulator.py
```
Leave this running. Every flagged flow is printed and logged to
`logs/alerts.db`. Stop anytime with Ctrl+C, or run `--count 500` for a
bounded demo run.

**4. Start the dashboard** (in a second terminal):
```bash
python3 dashboard/app.py
```
Open **http://127.0.0.1:5000** — you'll see alerts streaming in live,
severity breakdown, top targeted ports, and detected pattern types,
auto-refreshing every 3 seconds.

## Monitoring REAL traffic instead of simulated

Swap the data source, keep everything else:

```bash
pip install scapy
sudo python3 src/live_capture.py --iface eth0      # Linux
sudo python3 src/live_capture.py --iface "Wi-Fi"   # Windows/macOS, run as Administrator
```

This sniffs real packets, groups them into 5-tuple flows over a 5-second
window, converts them to the exact same feature schema, and feeds the same
`AnomalyDetector`. The dashboard doesn't need to know or care whether
traffic is real or simulated.

> Only run packet capture on networks you own or have explicit permission to
> monitor.

## Tuning it for your environment

- `IsolationForest(contamination=0.08, ...)` in `train_model.py` — lower
  this if your real traffic has fewer anomalies than the 8% synthetic
  default, or the model will flag too much normal traffic.
- `error_threshold` (92nd percentile of reconstruction error) — raise the
  percentile to reduce false positives, lower it to catch more borderline
  cases.
- `WINDOW_SECONDS` in `live_capture.py` — how long to aggregate packets into
  one flow before scoring it. Shorter windows react faster but see less
  context per flow.
- Retrain periodically on your own captured "known-good" traffic so the
  baseline reflects your actual network, not the synthetic generator's
  assumptions.

## Limitations (be upfront about these)

- The synthetic dataset approximates attack *shapes*; it is not a substitute
  for real datasets like CICIDS2017 or a live pilot on your own network
  before trusting this in production.
- `failed_logins` detection needs application-layer parsing (SSH/FTP/RDP
  auth logs) to populate from real traffic — `live_capture.py` currently
  leaves it at 0 for real packets since that requires deeper protocol
  inspection than raw packet headers give you.
- This is a detection aid for a human analyst, not an automated blocking
  system. Pair it with your firewall/IPS if you want automatic response.
