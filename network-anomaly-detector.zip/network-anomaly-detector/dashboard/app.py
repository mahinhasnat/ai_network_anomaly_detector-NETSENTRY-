"""
dashboard/app.py
------------------
Flask web dashboard for the network anomaly detector. Reads alerts from
logs/alerts.db (written by src/detector.py) and displays them live.

Run:
    python3 dashboard/app.py
Then open http://127.0.0.1:5000
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import sqlite3
from flask import Flask, jsonify, render_template

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "logs", "alerts.db")

app = Flask(__name__)


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/alerts")
def api_alerts():
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM alerts ORDER BY ts DESC LIMIT 200"
    ).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


@app.route("/api/stats")
def api_stats():
    conn = get_db()
    total = conn.execute("SELECT COUNT(*) c FROM alerts").fetchone()["c"]
    by_severity = conn.execute(
        "SELECT severity, COUNT(*) c FROM alerts GROUP BY severity"
    ).fetchall()
    by_attack_type = conn.execute(
        "SELECT true_attack_type, COUNT(*) c FROM alerts GROUP BY true_attack_type ORDER BY c DESC"
    ).fetchall()
    by_dst_port = conn.execute(
        "SELECT dst_port, COUNT(*) c FROM alerts GROUP BY dst_port ORDER BY c DESC LIMIT 10"
    ).fetchall()
    conn.close()
    return jsonify({
        "total": total,
        "by_severity": {r["severity"]: r["c"] for r in by_severity},
        "by_attack_type": {r["true_attack_type"]: r["c"] for r in by_attack_type},
        "by_dst_port": [{"port": r["dst_port"], "count": r["c"]} for r in by_dst_port],
    })


if __name__ == "__main__":
    app.run(debug=True, port=5000)
